from django.shortcuts import render, get_object_or_404, redirect
from django.shortcuts import render
from django.http import HttpResponse
from .models import Account


# Create your views here.
def index(request):
    bank_account = Account.accounts.all()
    context = {'bank_accounts': bank_account}
    return render(request, 'mainapp/index.html', context)
