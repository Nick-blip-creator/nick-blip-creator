from django.db import models
from django.conf import settings


class Account(models.Model):
    first_name = models.CharField(max_length=60)
    last_name = models.CharField(max_length=60, default="", blank=True, null=False)
    start_balance = models.DecimalField(default=0.00, max_digits=100000, decimal_places=4)

    objects = models.Manager()

    def __str__(self):
        return self.name


TYPE_CHOICES = {
    ('deposit', 'deposit'),
    ('withdraw', 'withdraw'),
}


class Transaction(models.Model):
    date_transaction = models.DateField()
    type_transaction = models.CharField(max_length=60, choices=TYPE_CHOICES)
    description = models.TextField(max_length=300, default="", blank=True)
    account = models.ForeignKey(Account, on_delete=models.DO_NOTHING, null=False)
